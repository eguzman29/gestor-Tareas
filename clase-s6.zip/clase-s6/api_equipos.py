# api_equipos.py — Ejemplo de referencia de la Unidad III, Sesión 6
# Programación Distribuida · Facultad de Telemática · Universidad de Colima
#
# La API de la sesión 4 (SQLite, OpenAPI, login con JWT, roles y préstamos con dueño), ahora
# también es CLIENTE de otros servicios:
#   1. POST /reportes: la IA (Gemini) clasifica la gravedad de un reporte de falla (FEAT-402).
#   2. Al pedir un préstamo, avisa por correo con Idempotency-Key: nunca dos correos (INT-401).
#   3. Toda llamada externa lleva timeout, reintentos con espera creciente y validación.
#   4. Las claves y direcciones salen de variables de entorno, nunca del código.
#   5. (Sesión 6) CORS: solo las páginas de la lista CORS_ORIGENES pueden usarla desde el navegador.
#
# Cómo correrla:
#   pip install fastapi uvicorn pyjwt bcrypt
#   set GEMINI_API_KEY=tu-clave          (Windows; en Mac/Linux: export GEMINI_API_KEY=...)
#   uvicorn api_equipos:app --reload
#   http://127.0.0.1:8000/docs
#
# Para probarla con el simulador de fallas (probar_api.py lo arranca solo):
#   set EXTERNO_URL=http://127.0.0.1:9000
#   set CORREO_URL=http://127.0.0.1:9000
#
# Usuarios de prueba (se crean solos la primera vez):
#   encargado / encargado123   rol: encargado
#   ana       / ana12345       rol: alumno
#   beto      / beto12345      rol: alumno

import json
import os
import random
import socket
import sqlite3
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import List, Literal, Optional

import bcrypt
import jwt
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

app = FastAPI(
    title="Préstamo de equipo del laboratorio",
    version="6.0",
    description="CRUD de equipos con SQLite, login con JWT, roles, préstamos con dueño, "
                "reportes clasificados con IA y aviso por correo. "
                "Todos los errores responden {\"error\", \"detalles\"}.",
)

BD = "equipos.db"
# La clave para FIRMAR los tokens. En producción sale de una variable de entorno y nunca se sube a GitHub.
SECRETO = os.environ.get("JWT_SECRETO", "clave-de-desarrollo-cambiala-en-produccion-2026")
MINUTOS_TOKEN = 30


# ============================================================
# 1. LA BASE DE DATOS
# ============================================================

def conectar():
    con = sqlite3.connect(BD)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def hash_de(clave: str) -> str:
    # bcrypt agrega una "sal" aleatoria: la misma clave da un hash distinto cada vez
    return bcrypt.hashpw(clave.encode(), bcrypt.gensalt(rounds=12)).decode()


def preparar_bd():
    with conectar() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS equipos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL, tipo TEXT NOT NULL,
            inventario TEXT NOT NULL UNIQUE,
            estado TEXT NOT NULL DEFAULT 'disponible')""")
        con.execute("""CREATE TABLE IF NOT EXISTS usuarios (
            usuario TEXT PRIMARY KEY,
            clave_hash TEXT NOT NULL,              -- el hash, NUNCA la clave
            rol TEXT NOT NULL CHECK (rol IN ('encargado', 'alumno')))""")
        con.execute("""CREATE TABLE IF NOT EXISTS prestamos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipo_id INTEGER NOT NULL REFERENCES equipos(id),
            usuario TEXT NOT NULL REFERENCES usuarios(usuario),   -- el DUEÑO del préstamo
            fecha TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS reportes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipo_id INTEGER NOT NULL REFERENCES equipos(id),
            usuario TEXT NOT NULL, descripcion TEXT NOT NULL,
            gravedad TEXT NOT NULL, resumen TEXT NOT NULL, fecha TEXT NOT NULL)""")
        if con.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 0:
            for u, c, r in [("encargado", "encargado123", "encargado"),
                            ("ana", "ana12345", "alumno"), ("beto", "beto12345", "alumno")]:
                con.execute("INSERT INTO usuarios VALUES (?, ?, ?)", (u, hash_de(c), r))
        if con.execute("SELECT COUNT(*) FROM equipos").fetchone()[0] == 0:
            con.execute("INSERT INTO equipos (nombre, tipo, inventario) VALUES "
                        "('Multímetro Fluke 115', 'multimetro', 'LAB-001'), ('Arduino UNO R3', 'arduino', 'LAB-002')")


preparar_bd()


# ============================================================
# 2. MODELOS Y FORMATO DE ERROR (igual que en las sesiones 2 y 3)
# ============================================================

class EquipoNuevo(BaseModel):
    nombre: str = Field(..., min_length=2, max_length=60, examples=["Multímetro Fluke 115"])
    tipo: Literal["multimetro", "arduino", "osciloscopio", "fuente"]
    inventario: str = Field(..., pattern=r"^LAB-\d{3}$", examples=["LAB-001"])


class Equipo(EquipoNuevo):
    id: int
    estado: Literal["disponible", "prestado", "reparacion"]


class Credenciales(BaseModel):
    usuario: str = Field(..., examples=["ana"])
    clave: str = Field(..., max_length=72, examples=["ana12345"])   # bcrypt usa hasta 72 bytes


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expira_en_segundos: int


class PrestamoNuevo(BaseModel):
    equipo_id: int = Field(..., examples=[1])


class Prestamo(BaseModel):
    id: int
    equipo_id: int
    usuario: str
    fecha: str
    notificado: Optional[bool] = None      # ¿se pudo mandar el correo? (None = correo no configurado)


class ErrorRespuesta(BaseModel):
    error: str
    detalles: List[str] = []


def E(codigo, texto):
    return {codigo: {"model": ErrorRespuesta, "description": texto}}


E400, E404, E409, E422 = E(400, "El cuerpo no es un JSON válido"), E(404, "No existe"), \
    E(409, "Choca con lo que ya hay"), E(422, "Los datos no cumplen las reglas")
E401 = E(401, "Falta el token, es falso o ya expiró")
E403 = E(403, "Tu rol no tiene permiso para esta operación")


def error(codigo, mensaje, detalles=None, encabezados=None):
    return JSONResponse(status_code=codigo, content={"error": mensaje, "detalles": detalles or []},
                        headers=encabezados)


@app.exception_handler(HTTPException)
async def error_http(request: Request, exc: HTTPException):
    return error(exc.status_code, exc.detail, encabezados=exc.headers)


@app.exception_handler(RequestValidationError)
async def error_validacion(request: Request, exc: RequestValidationError):
    errores = exc.errors()
    if any(e["type"] == "json_invalid" for e in errores):
        return error(400, "El cuerpo no es un JSON válido")
    return error(422, "Los datos no son válidos",
                 [f"{'.'.join(str(x) for x in e['loc'][1:])}: {e['msg']}" for e in errores])


@app.exception_handler(Exception)
async def error_interno(request: Request, exc: Exception):
    return error(500, "Error interno del servidor")


# ============================================================
# 3. AUTENTICACIÓN: ¿QUIÉN ERES?  (login -> token -> verificar el token en cada petición)
# ============================================================

@app.post("/login", response_model=Token, responses=E(401, "Usuario o clave incorrectos"),
          tags=["sesión"], summary="Entrar: cambia usuario y clave por un token")
def login(c: Credenciales):
    with conectar() as con:
        fila = con.execute("SELECT * FROM usuarios WHERE usuario = ?", (c.usuario,)).fetchone()
    # Mismo mensaje si no existe el usuario o si la clave está mal: no le digas al atacante cuál falló
    if fila is None or not bcrypt.checkpw(c.clave.encode(), fila["clave_hash"].encode()):
        raise HTTPException(401, "Usuario o clave incorrectos")
    ahora = datetime.now(timezone.utc)
    datos = {"sub": fila["usuario"], "rol": fila["rol"],           # lo que el token "dice" de ti
             "iat": ahora, "exp": ahora + timedelta(minutes=MINUTOS_TOKEN)}
    token = jwt.encode(datos, SECRETO, algorithm="HS256")          # firmado con la clave del servidor
    return {"access_token": token, "token_type": "bearer", "expira_en_segundos": MINUTOS_TOKEN * 60}


bearer = HTTPBearer(auto_error=False)   # lee el encabezado  Authorization: Bearer <token>
SIN_SESION = {"WWW-Authenticate": "Bearer"}


def usuario_actual(cred: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    if cred is None:
        raise HTTPException(401, "Falta el token: inicia sesión en POST /login", headers=SIN_SESION)
    try:
        datos = jwt.decode(cred.credentials, SECRETO, algorithms=["HS256"])   # revisa firma y expiración
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "El token ya expiró: inicia sesión otra vez", headers=SIN_SESION)
    except jwt.InvalidTokenError:
        raise HTTPException(401, "El token no es válido (¿lo modificaste?)", headers=SIN_SESION)
    return {"usuario": datos["sub"], "rol": datos["rol"]}


# ============================================================
# 4. AUTORIZACIÓN: ¿QUÉ PUEDES HACER?  (rol -> 403)
# ============================================================

def solo_encargado(yo: dict = Depends(usuario_actual)) -> dict:
    if yo["rol"] != "encargado":
        raise HTTPException(403, f"Tu rol ({yo['rol']}) no puede hacer esto: solo el encargado")
    return yo


@app.get("/yo", tags=["sesión"], responses=E401, summary="¿Quién dice el token que soy?")
def quien_soy(yo: dict = Depends(usuario_actual)):
    return yo


# ============================================================
# 5. EQUIPOS: consultar es público; cambiar es solo del encargado
# ============================================================

def buscar_equipo(con, equipo_id: int):
    fila = con.execute("SELECT * FROM equipos WHERE id = ?", (equipo_id,)).fetchone()
    if fila is None:
        raise HTTPException(404, f"No existe el equipo {equipo_id}")
    return dict(fila)


@app.get("/equipos", response_model=List[Equipo], tags=["equipos"], summary="Listar equipos (público)")
def listar():
    with conectar() as con:
        return [dict(f) for f in con.execute("SELECT * FROM equipos ORDER BY id")]


@app.get("/equipos/{equipo_id}", response_model=Equipo, responses=E404, tags=["equipos"],
         summary="Consultar un equipo (público)")
def consultar(equipo_id: int):
    with conectar() as con:
        return buscar_equipo(con, equipo_id)


@app.post("/equipos", status_code=201, response_model=Equipo,
          responses={**E400, **E401, **E403, **E409, **E422}, tags=["equipos"], summary="Crear (encargado)")
def crear(datos: EquipoNuevo, response: Response, yo: dict = Depends(solo_encargado)):
    with conectar() as con:
        try:
            cur = con.execute("INSERT INTO equipos (nombre, tipo, inventario) VALUES (?, ?, ?)",
                              (datos.nombre, datos.tipo, datos.inventario))
        except sqlite3.IntegrityError:
            raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
        response.headers["Location"] = f"/equipos/{cur.lastrowid}"
        return buscar_equipo(con, cur.lastrowid)


@app.put("/equipos/{equipo_id}", response_model=Equipo,
         responses={**E400, **E401, **E403, **E404, **E409, **E422}, tags=["equipos"], summary="Reemplazar (encargado)")
def reemplazar(equipo_id: int, datos: EquipoNuevo, yo: dict = Depends(solo_encargado)):
    with conectar() as con:
        buscar_equipo(con, equipo_id)
        try:
            con.execute("UPDATE equipos SET nombre = ?, tipo = ?, inventario = ? WHERE id = ?",
                        (datos.nombre, datos.tipo, datos.inventario, equipo_id))
        except sqlite3.IntegrityError:
            raise HTTPException(409, f"Ya existe un equipo con inventario {datos.inventario}")
        return buscar_equipo(con, equipo_id)


@app.delete("/equipos/{equipo_id}", status_code=204, responses={**E401, **E403, **E404, **E409},
            tags=["equipos"], summary="Borrar (encargado)")
def borrar(equipo_id: int, yo: dict = Depends(solo_encargado)):
    with conectar() as con:
        if buscar_equipo(con, equipo_id)["estado"] == "prestado":
            raise HTTPException(409, "No se puede borrar un equipo que está prestado")
        con.execute("DELETE FROM equipos WHERE id = ?", (equipo_id,))
    return Response(status_code=204)


# ============================================================
# 6. PRÉSTAMOS: cada uno tiene DUEÑO  (ticket SEC-311 · OWASP API1:2023)
#    El dueño sale del TOKEN, nunca de lo que mande el cliente.
# ============================================================

def buscar_prestamo(con, prestamo_id: int, yo: dict):
    if yo["rol"] == "encargado":
        fila = con.execute("SELECT * FROM prestamos WHERE id = ?", (prestamo_id,)).fetchone()
    else:
        # la línea que corrige SEC-311: además del id, el préstamo tiene que ser MÍO
        fila = con.execute("SELECT * FROM prestamos WHERE id = ? AND usuario = ?",
                           (prestamo_id, yo["usuario"])).fetchone()
    if fila is None:
        # 404 y no 403: no le confirmamos a nadie que ese préstamo existe
        raise HTTPException(404, f"No existe el préstamo {prestamo_id}")
    return dict(fila)


@app.get("/prestamos", response_model=List[Prestamo], responses=E401, tags=["préstamos"],
         summary="Mis préstamos (el encargado ve todos)")
def mis_prestamos(yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        if yo["rol"] == "encargado":
            filas = con.execute("SELECT * FROM prestamos ORDER BY id")
        else:
            filas = con.execute("SELECT * FROM prestamos WHERE usuario = ? ORDER BY id", (yo["usuario"],))
        return [dict(f) for f in filas]


@app.post("/prestamos", status_code=201, response_model=Prestamo,
          responses={**E400, **E401, **E404, **E409, **E422}, tags=["préstamos"], summary="Pedir un equipo prestado")
def pedir_prestamo(datos: PrestamoNuevo, response: Response, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        if buscar_equipo(con, datos.equipo_id)["estado"] != "disponible":
            raise HTTPException(409, f"El equipo {datos.equipo_id} no está disponible")
        cur = con.execute("INSERT INTO prestamos (equipo_id, usuario, fecha) VALUES (?, ?, ?)",
                          (datos.equipo_id, yo["usuario"], datetime.now().isoformat(timespec="seconds")))
        con.execute("UPDATE equipos SET estado = 'prestado' WHERE id = ?", (datos.equipo_id,))
        response.headers["Location"] = f"/prestamos/{cur.lastrowid}"
        p = buscar_prestamo(con, cur.lastrowid, yo)
    # INT-401: avisar por correo. Si el servicio de correo falla, el préstamo NO se pierde.
    p["notificado"] = avisar_por_correo(f"{yo['usuario']}@ucol.mx", f"Préstamo {p['id']}: equipo {p['equipo_id']}",
                                        llave=f"prestamo-{p['id']}")
    return p


@app.get("/prestamos/{prestamo_id}", response_model=Prestamo, responses={**E401, **E404}, tags=["préstamos"],
         summary="Consultar un préstamo (solo el dueño o el encargado)")
def consultar_prestamo(prestamo_id: int, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        return buscar_prestamo(con, prestamo_id, yo)


@app.delete("/prestamos/{prestamo_id}", status_code=204, responses={**E401, **E404}, tags=["préstamos"],
            summary="Cancelar o devolver un préstamo (solo el dueño o el encargado)")
def cancelar_prestamo(prestamo_id: int, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        p = buscar_prestamo(con, prestamo_id, yo)
        con.execute("DELETE FROM prestamos WHERE id = ?", (prestamo_id,))
        con.execute("UPDATE equipos SET estado = 'disponible' WHERE id = ?", (p["equipo_id"],))
    return Response(status_code=204)


# ============================================================
# 7. DEMO DE CLASE: así estaba antes de SEC-311. NUNCA hagan esto.
# ============================================================

@app.get("/demo/prestamo-inseguro/{prestamo_id}", tags=["demo: SEC-311"],
         summary="NO HACER: pide token, pero no revisa de quién es el préstamo")
def prestamo_inseguro(prestamo_id: int, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        fila = con.execute("SELECT * FROM prestamos WHERE id = ?", (prestamo_id,)).fetchone()   # falta: AND usuario = ?
    if fila is None:
        raise HTTPException(404, f"No existe el préstamo {prestamo_id}")
    return {"lo_pidio": yo["usuario"], "prestamo": dict(fila)}


# ============================================================
# 8. SU API COMO CLIENTE DE OTROS SERVICIOS  (sesión 5)
#    Todo lo que depende de otro servidor: timeout, reintentos con criterio y validación.
# ============================================================

EXTERNO_URL = os.environ.get("EXTERNO_URL", "https://generativelanguage.googleapis.com").rstrip("/")
CORREO_URL = os.environ.get("CORREO_URL", "").rstrip("/")             # vacío = no se manda correo
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")                   # NUNCA escrita en el código
GEMINI_MODELO = os.environ.get("GEMINI_MODELO", "gemini-flash-lite-latest")
TIMEOUT = float(os.environ.get("EXTERNO_TIMEOUT", "2"))   # segundos máximos esperando al otro servidor (por intento)
INTENTOS = 3           # 1 intento + 2 reintentos
TRANSITORIOS = {429, 500, 502, 503, 504}   # fallas pasajeras: vale la pena reintentar


def llamar_externo(metodo: str, url: str, cuerpo=None, encabezados=None, llave=None):
    """Llama a un servicio externo. Regresa el JSON de la respuesta o lanza HTTPException 502/504."""
    datos = json.dumps(cuerpo).encode() if cuerpo is not None else None
    for intento in range(1, INTENTOS + 1):
        req = urllib.request.Request(url, data=datos, method=metodo)
        req.add_header("Content-Type", "application/json")
        for k, v in (encabezados or {}).items():
            req.add_header(k, v)
        if llave:
            req.add_header("Idempotency-Key", llave)   # la MISMA llave en todos los intentos
        espera_minima = 0
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                estado, texto = r.status, r.read()
        except urllib.error.HTTPError as e:
            estado, texto = e.code, e.read()
            espera_minima = float(e.headers.get("Retry-After") or 0) if e.code == 429 else 0
        except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError):
            estado, texto = None, b""                   # no respondió a tiempo o no hubo conexión
        if estado is not None and estado not in TRANSITORIOS:
            break                                      # éxito, o un error que no se arregla reintentando (400, 401, 404...)
        if intento < INTENTOS:
            espera = max(espera_minima, 0.5 * 2 ** (intento - 1)) + random.uniform(0, 0.2)   # 0.5 s, 1 s... + azar
            print(f"[externo] intento {intento}: {estado or 'sin respuesta a tiempo'} -> reintento en {espera:.1f} s", flush=True)
            time.sleep(espera)
    if estado is None:
        raise HTTPException(504, f"El servicio externo no respondió a tiempo ({INTENTOS} intentos de {TIMEOUT:g} s)")
    if estado in TRANSITORIOS:
        raise HTTPException(502, f"El servicio externo sigue fallando ({estado}) después de {INTENTOS} intentos")
    if estado >= 400:
        raise HTTPException(502, f"El servicio externo rechazó la petición ({estado}); no se reintenta")
    try:
        return json.loads(texto)
    except ValueError:
        raise HTTPException(502, "El servicio externo respondió algo que no es JSON")


# ---------- FEAT-402: la IA clasifica un reporte de falla ----------

class ReporteNuevo(BaseModel):
    equipo_id: int = Field(..., examples=[1])
    descripcion: str = Field(..., min_length=5, max_length=500,
                             examples=["El multímetro marca 0 V en todas las escalas y huele a quemado"])


class Reporte(BaseModel):
    id: int
    equipo_id: int
    usuario: str
    descripcion: str
    gravedad: Literal["alta", "media", "baja"]
    resumen: str
    fecha: str


INSTRUCCION = ("Eres el encargado de un laboratorio de electrónica. Clasifica la gravedad del siguiente "
               "reporte de falla de un equipo y responde SOLO un objeto JSON con la forma "
               '{"gravedad": "alta" | "media" | "baja", "resumen": "máximo 20 palabras en español"}. '
               "Alta = riesgo eléctrico o el equipo no funciona; media = funciona mal; baja = detalle menor.\n"
               "Reporte: ")


E502 = E(502, "El servicio externo falló o respondió algo inválido")
E504 = E(504, "El servicio externo no respondió a tiempo")


@app.post("/reportes", status_code=201, response_model=Reporte,
          responses={**E401, **E404, **E422, **E502, **E504, **E(503, "Falta configurar la IA")},
          tags=["reportes (IA)"], summary="Reportar una falla: la IA clasifica su gravedad")
def reportar_falla(datos: ReporteNuevo, yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        buscar_equipo(con, datos.equipo_id)
    if not GEMINI_API_KEY and "googleapis.com" in EXTERNO_URL:
        raise HTTPException(503, "Falta configurar la variable de entorno GEMINI_API_KEY")
    # A la IA solo le mandamos la descripción: ni el usuario ni otros datos personales.
    respuesta = llamar_externo(
        "POST", f"{EXTERNO_URL}/v1beta/models/{GEMINI_MODELO}:generateContent",
        {"contents": [{"parts": [{"text": INSTRUCCION + datos.descripcion}]}],
         "generationConfig": {"responseMimeType": "application/json", "temperature": 0}},
        {"x-goog-api-key": GEMINI_API_KEY})
    # La IA no es determinista: NUNCA confíes en que respondió lo que pediste. Valida.
    try:
        ia = json.loads(respuesta["candidates"][0]["content"]["parts"][0]["text"])
        gravedad, resumen = ia["gravedad"], str(ia["resumen"]).strip()[:200]
        if gravedad not in ("alta", "media", "baja") or not resumen:
            raise ValueError
    except (KeyError, IndexError, TypeError, ValueError):
        raise HTTPException(502, "La IA respondió en un formato inesperado")
    with conectar() as con:
        cur = con.execute("INSERT INTO reportes (equipo_id, usuario, descripcion, gravedad, resumen, fecha) "
                          "VALUES (?, ?, ?, ?, ?, ?)", (datos.equipo_id, yo["usuario"], datos.descripcion,
                                                        gravedad, resumen, datetime.now().isoformat(timespec="seconds")))
        return dict(con.execute("SELECT * FROM reportes WHERE id = ?", (cur.lastrowid,)).fetchone())


@app.get("/reportes", response_model=List[Reporte], responses=E401, tags=["reportes (IA)"],
         summary="Mis reportes (el encargado ve todos)")
def mis_reportes(yo: dict = Depends(usuario_actual)):
    with conectar() as con:
        if yo["rol"] == "encargado":
            return [dict(f) for f in con.execute("SELECT * FROM reportes ORDER BY id")]
        return [dict(f) for f in con.execute("SELECT * FROM reportes WHERE usuario = ? ORDER BY id", (yo["usuario"],))]


# ---------- INT-401: avisar por correo sin mandar dos veces ----------

def avisar_por_correo(para: str, asunto: str, llave: str):
    """True si se mandó, False si el servicio de correo falló, None si no está configurado."""
    if not CORREO_URL:
        return None
    try:
        llamar_externo("POST", f"{CORREO_URL}/correos", {"para": para, "asunto": asunto, "texto": asunto}, llave=llave)
        return True
    except HTTPException:
        return False          # el préstamo ya quedó guardado: un tercero caído no tumba nuestra API


@app.post("/demo/correo-sin-llave", tags=["demo: INT-401"], summary="NO HACER: reintenta sin Idempotency-Key")
def correo_sin_llave(yo: dict = Depends(usuario_actual)):
    llamar_externo("POST", f"{CORREO_URL or 'http://127.0.0.1:9000'}/correos",
                   {"para": f"{yo['usuario']}@ucol.mx", "asunto": "Prueba sin llave", "texto": "-"})
    return {"resultado": "la API cree que mandó UN correo"}


@app.post("/demo/correo-con-llave", tags=["demo: INT-401"], summary="Correcto: reintenta con la misma Idempotency-Key")
def correo_con_llave(yo: dict = Depends(usuario_actual)):
    llave = f"demo-{yo['usuario']}-{time.time_ns()}"
    llamar_externo("POST", f"{CORREO_URL or 'http://127.0.0.1:9000'}/correos",
                   {"para": f"{yo['usuario']}@ucol.mx", "asunto": "Prueba con llave", "texto": "-"}, llave=llave)
    return {"resultado": "la API cree que mandó UN correo", "idempotency_key": llave}


# ============================================================
# 9. LO MÍNIMO PARA SU PROYECTO: preguntarle algo a la IA sin que su API se caiga
#    Es la misma función del kit (kit_u3s5.html). Tres ideas:
#      1. Su API también puede LLAMAR a otra API (aquí, Gemini).
#      2. Esa otra API puede tardar o fallar: tiempo máximo de espera y un mensaje claro.
#      3. La clave va fuera del código, en una variable de entorno.
#    Lo de la sección 8 (reintentos, Idempotency-Key) es el "nivel 2".
# ============================================================

IA_URL = EXTERNO_URL                       # en clase apunta al simulador; si no, a Google
IA_MODELO = GEMINI_MODELO
IA_CLAVE = GEMINI_API_KEY                  # IDEA 3: sale de la variable de entorno GEMINI_API_KEY


def preguntar_a_la_ia(instruccion: str) -> dict:
    """Le pregunta algo a Gemini y regresa el JSON que contestó. Si algo sale mal, responde 502/503/504."""
    if not IA_CLAVE and "googleapis.com" in IA_URL:
        raise HTTPException(503, "Falta configurar la variable de entorno GEMINI_API_KEY")
    cuerpo = {"contents": [{"parts": [{"text": instruccion}]}],
              "generationConfig": {"responseMimeType": "application/json", "temperature": 0}}
    req = urllib.request.Request(f"{IA_URL}/v1beta/models/{IA_MODELO}:generateContent",
                                 data=json.dumps(cuerpo).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": IA_CLAVE})
    try:                                                         # IDEA 1: nuestra API llama a otra API
        with urllib.request.urlopen(req, timeout=5) as r:        # IDEA 2: máximo 5 segundos esperando
            respuesta = json.loads(r.read())
        return json.loads(respuesta["candidates"][0]["content"]["parts"][0]["text"])
    except TimeoutError:
        raise HTTPException(504, "La IA tardó demasiado en responder. Intenta en un momento.")
    except urllib.error.HTTPError as e:
        raise HTTPException(502, f"La IA no está disponible (respondió {e.code}). Intenta más tarde.")
    except urllib.error.URLError as e:
        if isinstance(e.reason, TimeoutError):
            raise HTTPException(504, "La IA tardó demasiado en responder. Intenta en un momento.")
        raise HTTPException(502, "No se pudo conectar con la IA.")
    except (ValueError, KeyError, IndexError, TypeError):
        raise HTTPException(502, "La IA respondió algo que no entendemos.")


# ---------- La página de la clase: http://127.0.0.1:8000/demo ----------
# Dos "apps" mandan el mismo reporte: una SIN protección y otra CON protección.
# Con los botones de la página, el simulador hace que la IA funcione, tarde, se caiga o responda basura.

class TextoDemo(BaseModel):
    descripcion: str = Field(..., min_length=5, max_length=500)


@app.post("/demo/sin-proteccion", tags=["demo: la página /demo"], summary="NO HACER: sin tiempo máximo y sin validar")
def demo_sin_proteccion(datos: TextoDemo):
    cuerpo = {"contents": [{"parts": [{"text": INSTRUCCION + datos.descripcion}]}],
              "generationConfig": {"responseMimeType": "application/json", "temperature": 0}}
    req = urllib.request.Request(f"{IA_URL}/v1beta/models/{IA_MODELO}:generateContent",
                                 data=json.dumps(cuerpo).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": IA_CLAVE})
    respuesta = json.loads(urllib.request.urlopen(req).read())        # sin timeout: espera lo que haga falta
    ia = json.loads(respuesta["candidates"][0]["content"]["parts"][0]["text"])
    return {"gravedad": ia["gravedad"], "resumen": ia["resumen"]}    # y confía en lo que llegó


@app.post("/demo/con-proteccion", tags=["demo: la página /demo"], summary="Correcto: preguntar_a_la_ia() y validar")
def demo_con_proteccion(datos: TextoDemo):
    ia = preguntar_a_la_ia(INSTRUCCION + datos.descripcion)
    if not isinstance(ia, dict) or ia.get("gravedad") not in ("alta", "media", "baja"):   # nunca confíes: valida
        raise HTTPException(502, "La IA respondió algo inesperado.")
    return {"gravedad": ia["gravedad"], "resumen": str(ia.get("resumen", ""))[:200]}


SIMULADOR = IA_URL if "googleapis.com" not in IA_URL else os.environ.get("SIMULADOR_URL", "http://127.0.0.1:9000")
MODOS_DEMO = {"funciona": "normal", "lenta": "lento", "caida": "falla_siempre", "basura": "basura"}


def simulador(datos=None):
    req = urllib.request.Request(SIMULADOR + "/_control", data=json.dumps(datos).encode() if datos else None,
                                 method="POST" if datos else "GET", headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=2) as r:
        return json.loads(r.read())


@app.get("/demo/estado", tags=["demo: la página /demo"], summary="¿A qué IA está conectada la API?")
def demo_estado():
    conectada = "googleapis.com" not in IA_URL
    try:
        s = simulador() if conectada else None
    except Exception:
        s = None
    return {"conectada_al_simulador": bool(s),
            "modo": {v: k for k, v in MODOS_DEMO.items()}.get(s["modo"], s["modo"]) if s else None,
            "ia": ("Gemini real" if s and str(s.get("reenvia_a", "")).startswith("http") else "simulada") if s
                  else ("Gemini real" if IA_CLAVE else "sin clave"),
            "timeout_segundos": 5}


@app.post("/demo/simulador/{modo}", tags=["demo: la página /demo"], summary="Cambiar cómo se porta la IA")
def demo_cambiar_modo(modo: Literal["funciona", "lenta", "caida", "basura"]):
    try:
        simulador({"modo": MODOS_DEMO[modo], "segundos": 15, "reiniciar": True})
    except Exception:
        raise HTTPException(503, "No encuentro el simulador. Arranca la clase con: python puente.py")
    return demo_estado()


@app.get("/demo", include_in_schema=False)
def pagina_demo():
    from fastapi.responses import HTMLResponse
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pagina_demo.html")
    try:
        with open(ruta, encoding="utf-8") as f:
            return HTMLResponse(f.read())
    except OSError:
        return HTMLResponse("<h1>Falta pagina_demo.html junto a api_equipos.py</h1>", status_code=404)



# ============================================================
# 10. CORS (sesión 6): ¿qué páginas pueden usar esta API desde el navegador?
#     curl y Postman no preguntan: el NAVEGADOR sí. Si la página viene de otro origen
#     (otro puerto ya cuenta), el navegador solo le deja leer la respuesta si la API dice
#     Access-Control-Allow-Origin con el origen de esa página.
#     La lista sale de una variable de entorno, como la clave de la IA:
#        set CORS_ORIGENES=http://127.0.0.1:5500,http://localhost:5500
# ============================================================

from fastapi.middleware.cors import CORSMiddleware  # noqa: E402

CORS_ORIGENES = [o.strip() for o in os.environ.get(
    "CORS_ORIGENES", "http://127.0.0.1:5500,http://localhost:5500").split(",") if o.strip()]
CORS_ENCABEZADOS = ["Authorization", "Content-Type"]

if os.environ.get("DEMO_CORS") != "1":
    # Lo que va en SU proyecto: una lista de orígenes, nunca "*"
    app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGENES,
                       allow_methods=["GET", "POST", "PUT", "DELETE"],
                       allow_headers=CORS_ENCABEZADOS)
else:
    # ---------- Solo para la demostración de clase (python puente.py pone DEMO_CORS=1) ----------
    # Hace lo mismo que CORSMiddleware, pero la lista se puede cambiar en vivo y anota cada
    # petición en una bitácora para ver qué le llegó a la API y qué bloqueó el navegador.
    from collections import deque  # noqa: E402

    BITACORA = deque(maxlen=14)
    DEMO = {"origenes": list(CORS_ORIGENES), "encabezados": ["Content-Type"]}

    def anotar(metodo, ruta, origen, codigo, nota=""):
        BITACORA.append({"hora": time.strftime("%H:%M:%S"), "metodo": metodo, "ruta": ruta,
                         "origen": origen or "(ninguno: curl)", "codigo": codigo, "nota": nota})

    @app.middleware("http")
    async def cors_demo(request: Request, call_next):
        origen = request.headers.get("origin")
        ruta = request.url.path
        if ruta.startswith("/demo/cors"):
            return await call_next(request)
        permitido = origen in DEMO["origenes"]
        if request.method == "OPTIONS" and origen and request.headers.get("access-control-request-method"):
            # los orígenes de CORS_ORIGENES (el front en el 5500) tienen todo; el que se agrega en la demo empieza sin Authorization
            permitidos = CORS_ENCABEZADOS if origen in CORS_ORIGENES else DEMO["encabezados"]
            pedidos = [h.strip().lower() for h in request.headers.get("access-control-request-headers", "").split(",") if h.strip()]
            faltan = [h for h in pedidos if h not in [x.lower() for x in permitidos]]
            nota = "pregunta previa (preflight)" + (f": pide {', '.join(pedidos)}" if pedidos else "")
            if not permitido:
                anotar("OPTIONS", ruta, origen, 400, nota + " · origen NO está en la lista")
                return Response(status_code=400)
            anotar("OPTIONS", ruta, origen, 204, nota + (f" · NO permite {', '.join(faltan)}" if faltan else " · todo permitido"))
            return Response(status_code=204, headers={
                "Access-Control-Allow-Origin": origen, "Vary": "Origin", "Access-Control-Max-Age": "0",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE",
                "Access-Control-Allow-Headers": ", ".join(permitidos)})
        respuesta = await call_next(request)
        if permitido:
            respuesta.headers["Access-Control-Allow-Origin"] = origen
            respuesta.headers["Vary"] = "Origin"
        anotar(request.method, ruta, origen, respuesta.status_code,
               "" if not origen else ("con permiso CORS" if permitido else "SIN permiso CORS: el navegador no deja leerla"))
        return respuesta

    class CambioCors(BaseModel):
        origen: Optional[str] = None
        permitir_origen: Optional[bool] = None
        permitir_authorization: Optional[bool] = None

    @app.get("/demo/cors", tags=["demo: CORS"], summary="La lista actual y la bitácora")
    def demo_cors_estado():
        return {"origenes": DEMO["origenes"], "encabezados": DEMO["encabezados"], "bitacora": list(BITACORA)}

    @app.post("/demo/cors", tags=["demo: CORS"], summary="Cambiar la lista en vivo")
    def demo_cors_cambiar(c: CambioCors):
        if c.origen and c.permitir_origen is not None:
            if c.permitir_origen and c.origen not in DEMO["origenes"]:
                DEMO["origenes"].append(c.origen)
            if not c.permitir_origen and c.origen in DEMO["origenes"]:
                DEMO["origenes"].remove(c.origen)
        if c.permitir_authorization is not None:
            DEMO["encabezados"] = ["Authorization", "Content-Type"] if c.permitir_authorization else ["Content-Type"]
        return demo_cors_estado()

    @app.post("/demo/cors/reiniciar", tags=["demo: CORS"], summary="Regresar la demo al inicio")
    def demo_cors_reiniciar():
        DEMO.update(origenes=list(CORS_ORIGENES), encabezados=["Content-Type"])
        BITACORA.clear()
        return demo_cors_estado()
